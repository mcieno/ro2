var searchData=
[
  ['solution_5fto_5fplot_5fdat',['solution_to_plot_dat',['../tspplot_8h.html#ad2b92863be743409bf4cab367d3897aa',1,'tspplot.c']]]
];
