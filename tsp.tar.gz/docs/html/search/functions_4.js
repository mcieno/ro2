var searchData=
[
  ['generic_5fmodel',['Generic_model',['../tsp__solvers_8h.html#a62d6524426502dd397bedb7b18796f2c',1,'tsp_solvers_Generic.c']]],
  ['genericconcorde_5fmodel',['GenericConcorde_model',['../tsp__solvers_8h.html#a4db4e109edd8549a0fa885329d795ba8',1,'tsp_solvers_GenericConcorde.c']]],
  ['genericconcorderand_5fmodel',['GenericConcordeRand_model',['../tsp__solvers_8h.html#ac3787ce5c9d5b5e9d2e33dabea03ed00',1,'tsp_solvers_GenericConcordeRand.c']]],
  ['genericconcordeshallow_5fmodel',['GenericConcordeShallow_model',['../tsp__solvers_8h.html#ab48de8671a1e8d008bd11045f53dae28',1,'tsp_solvers_GenericConcordeShallow.c']]]
];
