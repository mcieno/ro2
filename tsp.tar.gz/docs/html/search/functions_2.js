var searchData=
[
  ['destroy_5finstance',['destroy_instance',['../tsp_8h.html#abc983799ba1837b747050699cf322d22',1,'tsp.c']]],
  ['dummy_5fmodel',['Dummy_model',['../tsp__solvers_8h.html#a89107af986adc2dddb894d1a488ce4fd',1,'tsp_solvers_dummy.c']]]
];
