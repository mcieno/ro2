var searchData=
[
  ['tspconf_5fapply',['tspconf_apply',['../tspconf_8h.html#aae66c0ce7775c010f4694f8b7338c3b7',1,'tspconf.c']]],
  ['tspconf_5finit',['tspconf_init',['../tspconf_8h.html#a6fe28dc5389e39698e6d95a922ecdc64',1,'tspconf.c']]]
];
