var indexSectionsWithContent =
{
  0: "_cdfgilmprst",
  1: "cit",
  2: "lmt",
  3: "_cdfgilmprst",
  4: "t",
  5: "clmt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

