var searchData=
[
  ['mtz_5fmodel',['MTZ_model',['../tsp__solvers_8h.html#a7f6151b53b124a1e34dcf8448d60c1ca',1,'tsp_solvers_MTZ.c']]]
];
