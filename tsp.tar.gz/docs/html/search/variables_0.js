var searchData=
[
  ['tspplot_5ftmpfile',['tspplot_tmpfile',['../tspplot_8h.html#a1facbb721cde7d0816f47c799e99b80e',1,'tspplot.c']]]
];
