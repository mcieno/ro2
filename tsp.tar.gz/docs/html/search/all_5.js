var searchData=
[
  ['init_5finstance',['init_instance',['../tsp_8h.html#ab25d8f0a014badebe0d7b338e9c49697',1,'tsp.c']]],
  ['instance',['instance',['../structinstance.html',1,'']]],
  ['instance_5fto_5fplot_5fdat',['instance_to_plot_dat',['../tspplot_8h.html#a1fe08417a1888e4cfd335a8fcc1e5493',1,'tspplot.c']]]
];
